#ifndef DELAY_H_
#define DELAY_H_

void delay_init();
void delay_cycles(uint16_t cycles);
void delay_us(uint16_t us);

#endif /* DELAY_H_ */
