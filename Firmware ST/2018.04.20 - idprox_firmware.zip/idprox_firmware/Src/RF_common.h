#ifndef COMMON_H_
#define COMMON_H_

typedef enum {
	TIPO_ASK,
	TIPO_FSK,
	TIPO_PSK,
	TIPO_MIFARE,	
	TIPO_NUL
} TIPO_LEITOR;

#endif /* COMMON_H_ */
